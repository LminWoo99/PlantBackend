package Plant.PlantProject.dto;

import lombok.Data;

@Data
public class RoleDto {
    private String userName;
    private String roleName;
}
