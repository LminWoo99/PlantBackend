package Plant.PlantProject.Entity;

public enum DeleteStatus {
    Y,N
}
