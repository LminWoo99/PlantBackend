package Plant.PlantProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlantProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
