package Plant.PlantProject.Entity;

public enum Status {
    판매중,  거래완료
}
