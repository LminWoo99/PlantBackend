package Plant.PlantProject.Entity;

public enum SocialLogin {
    KAKAO,  NON
}
