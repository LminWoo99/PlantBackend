#!/bin/bash
/etc/server/PlantBackend/scripts/deploy.sh > /dev/null 2> /dev/null < /dev/null &